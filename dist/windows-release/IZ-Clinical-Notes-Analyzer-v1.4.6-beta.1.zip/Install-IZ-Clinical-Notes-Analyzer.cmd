@echo off
setlocal
set "PACKAGE_DIR=%~dp0"
cd /d "%PACKAGE_DIR%"
title Install IZ Clinical Notes Analyzer
echo IZ Clinical Notes Analyzer installer
echo.
echo This installs the app for the current Windows user. Administrator access is not required.
echo Existing local data under %%LOCALAPPDATA%%\IZ Clinical Notes Analyzer will be preserved.
echo Current treatment-plan handling docs are included under app\docs.
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PACKAGE_DIR%installer\install-windows-release.ps1" %*
set "EXIT_CODE=%ERRORLEVEL%"
echo.
if "%EXIT_CODE%"=="0" (
    echo [ok] Install completed.
    echo Launch from the Start Menu, Desktop shortcut, or Launch-IZ-Clinical-Notes-Analyzer.cmd.
) else (
    echo [fail] Install did not complete.
    echo Review the message above or send a screenshot of this window to R3 support.
)
echo.
pause
exit /b %EXIT_CODE%
