﻿[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$PackageDir = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$SourceAppDir = Join-Path $PackageDir 'app'
$InstallRoot = Join-Path $env:LOCALAPPDATA 'Programs\IZ Clinical Notes Analyzer'
$StartMenuDir = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\IZ Clinical Notes Analyzer'
$DesktopDir = [Environment]::GetFolderPath('Desktop')
$Launcher = Join-Path $InstallRoot 'scripts\Start-IZ-Clinical-Notes-Analyzer.cmd'
$StopLauncher = Join-Path $InstallRoot 'scripts\Stop-IZ-Clinical-Notes-Analyzer.cmd'
$DiagnosticsLauncher = Join-Path $InstallRoot 'scripts\Collect-IZ-Clinical-Notes-Analyzer-Diagnostics.cmd'
$BackupLauncher = Join-Path $InstallRoot 'scripts\Backup-IZ-Clinical-Notes-Analyzer.cmd'
$InstalledInstallerDir = Join-Path $InstallRoot 'installer'
$StartShortcut = Join-Path $StartMenuDir 'IZ Clinical Notes Analyzer.lnk'
$StopShortcut = Join-Path $StartMenuDir 'Stop IZ Clinical Notes Analyzer.lnk'
$DiagnosticsShortcut = Join-Path $StartMenuDir 'IZ Clinical Notes Analyzer Diagnostics.lnk'
$BackupShortcut = Join-Path $StartMenuDir 'Backup IZ Clinical Notes Analyzer.lnk'
$UninstallShortcut = Join-Path $StartMenuDir 'Uninstall IZ Clinical Notes Analyzer.lnk'
$CompleteUninstallShortcut = Join-Path $StartMenuDir 'Complete Uninstall IZ Clinical Notes Analyzer.lnk'
$DesktopStartShortcut = Join-Path $DesktopDir 'IZ Clinical Notes Analyzer.lnk'
$DesktopDiagnosticsShortcut = Join-Path $DesktopDir 'IZ Clinical Notes Analyzer Diagnostics.lnk'
$DesktopBackupShortcut = Join-Path $DesktopDir 'IZ Clinical Notes Analyzer Backup.lnk'
$Uninstaller = Join-Path $InstallRoot 'Uninstall-IZ-Clinical-Notes-Analyzer.cmd'
$CompleteUninstaller = Join-Path $InstallRoot 'Complete-Uninstall-IZ-Clinical-Notes-Analyzer.cmd'
$LocalDataDir = Join-Path $env:LOCALAPPDATA 'IZ Clinical Notes Analyzer'

function Write-InstallStep($Message) { Write-Host "[setup] $Message" }
function Write-InstallOk($Message) { Write-Host "[ok] $Message" -ForegroundColor Green }

function New-Shortcut {
    param(
        [string]$ShortcutPath,
        [string]$TargetPath,
        [string]$WorkingDirectory,
        [string]$IconLocation = ''
    )
    $shell = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut($ShortcutPath)
    $shortcut.TargetPath = $TargetPath
    $shortcut.WorkingDirectory = $WorkingDirectory
    $shortcut.IconLocation = if ($IconLocation) { $IconLocation } else { "$env:SystemRoot\System32\shell32.dll,220" }
    $shortcut.Save()
}

function Assert-RequiredPackageItem {
    param([string]$RelativePath)
    $path = Join-Path $PackageDir $RelativePath
    if (-not (Test-Path -LiteralPath $path)) {
        throw "This release package is incomplete. Missing: $RelativePath. Download or unzip the release package again."
    }
}

Assert-RequiredPackageItem 'app\backend'
Assert-RequiredPackageItem 'app\frontend\dist\index.html'
Assert-RequiredPackageItem 'app\scripts\preflight-windows.ps1'

Write-InstallStep "Installing app files to $InstallRoot"
New-Item -ItemType Directory -Path $InstallRoot, $StartMenuDir -Force | Out-Null
robocopy $SourceAppDir $InstallRoot /MIR /NFL /NDL /NJH /NJS /NP | Out-Null
if ($LASTEXITCODE -gt 7) { throw "Install copy failed with robocopy exit code $LASTEXITCODE" }
Copy-Item -LiteralPath (Join-Path $PackageDir 'release-manifest.json') -Destination (Join-Path $InstallRoot 'release-manifest.json') -Force
robocopy (Join-Path $PackageDir 'installer') $InstalledInstallerDir /MIR /NFL /NDL /NJH /NJS /NP | Out-Null
if ($LASTEXITCODE -gt 7) { throw "Installer helper copy failed with robocopy exit code $LASTEXITCODE" }

@"
@echo off
setlocal
set "NO_PAUSE="
for %%A in (%*) do (
    if /I "%%~A"=="-NoPause" set "NO_PAUSE=1"
    if /I "%%~A"=="/NoPause" set "NO_PAUSE=1"
)
title Uninstall IZ Clinical Notes Analyzer
echo Uninstall IZ Clinical Notes Analyzer app files
echo Local data under %%LOCALAPPDATA%%\IZ Clinical Notes Analyzer will be preserved.
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0installer\uninstall-windows-release.ps1" -InstalledAppRoot "%~dp0." %*
set "EXIT_CODE=%ERRORLEVEL%"
echo.
if "%EXIT_CODE%"=="0" (
    echo [ok] Uninstall completed. Local data was preserved.
) else (
    echo [fail] Uninstall did not complete.
)
echo.
if not "%NO_PAUSE%"=="1" pause
exit /b %EXIT_CODE%
"@ | Set-Content -Path $Uninstaller -Encoding ASCII

@"
@echo off
setlocal
set "NO_PAUSE="
for %%A in (%*) do (
    if /I "%%~A"=="-NoPause" set "NO_PAUSE=1"
    if /I "%%~A"=="/NoPause" set "NO_PAUSE=1"
)
title Complete Uninstall IZ Clinical Notes Analyzer
echo Complete uninstall removes app files AND local IZ Clinical Notes Analyzer data.
echo Use this only when R3 intentionally wants this Windows user account cleaned.
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\complete-uninstall-local-data.ps1" -InstalledAppRoot "%~dp0." %*
set "EXIT_CODE=%ERRORLEVEL%"
echo.
if "%EXIT_CODE%"=="0" (
    echo [ok] Complete uninstall finished.
) else (
    echo [fail] Complete uninstall did not complete.
)
echo.
if not "%NO_PAUSE%"=="1" pause
exit /b %EXIT_CODE%
"@ | Set-Content -Path $CompleteUninstaller -Encoding ASCII

Write-InstallStep 'Creating Start Menu and Desktop shortcuts'
New-Shortcut -ShortcutPath $StartShortcut -TargetPath $Launcher -WorkingDirectory $InstallRoot
New-Shortcut -ShortcutPath $StopShortcut -TargetPath $StopLauncher -WorkingDirectory $InstallRoot -IconLocation "$env:SystemRoot\System32\shell32.dll,27"
New-Shortcut -ShortcutPath $DiagnosticsShortcut -TargetPath $DiagnosticsLauncher -WorkingDirectory $InstallRoot -IconLocation "$env:SystemRoot\System32\shell32.dll,23"
New-Shortcut -ShortcutPath $BackupShortcut -TargetPath $BackupLauncher -WorkingDirectory $InstallRoot -IconLocation "$env:SystemRoot\System32\shell32.dll,258"
New-Shortcut -ShortcutPath $UninstallShortcut -TargetPath $Uninstaller -WorkingDirectory $InstallRoot
New-Shortcut -ShortcutPath $CompleteUninstallShortcut -TargetPath $CompleteUninstaller -WorkingDirectory $InstallRoot -IconLocation "$env:SystemRoot\System32\shell32.dll,131"
New-Shortcut -ShortcutPath $DesktopStartShortcut -TargetPath $Launcher -WorkingDirectory $InstallRoot
New-Shortcut -ShortcutPath $DesktopDiagnosticsShortcut -TargetPath $DiagnosticsLauncher -WorkingDirectory $InstallRoot -IconLocation "$env:SystemRoot\System32\shell32.dll,23"
New-Shortcut -ShortcutPath $DesktopBackupShortcut -TargetPath $BackupLauncher -WorkingDirectory $InstallRoot -IconLocation "$env:SystemRoot\System32\shell32.dll,258"

Write-InstallOk "Installed IZ Clinical Notes Analyzer to $InstallRoot"
Write-Host "Local data folder: $LocalDataDir"
Write-Host "Start Menu shortcut: $StartShortcut"
Write-InstallStep 'Running first-time preflight after install'
& (Join-Path $InstallRoot 'scripts\preflight-windows.ps1') -AssumeYes
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
Write-InstallOk 'Install complete. Use the Start Menu shortcut or Desktop shortcut to launch the app.'
