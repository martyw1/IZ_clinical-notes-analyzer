# Operations Runbook

Date: 2026-07-06

Applies to: IZ Clinical Notes Analyzer Beta Version `1.4.6-beta.1` / build `2026.06.30.1` local Windows desktop runtime.

## Health endpoints

- Backend direct: `GET /health`
- Backend API alias: `GET /api/health`
- Runtime readiness: `GET /api/readiness`
- Admin readiness details: `GET /api/system/readiness`
- Version metadata: `GET /api/version`

## Forensic log handling

- Primary forensic logs are stored in the `audit_logs` table.
- Each record includes request metadata, actor identity, source IP, event category, CEF payload, and a tamper-evident hash chain.
- If database persistence fails during logging, the app writes JSONL fallback records under the local app-data log directory.
- Admin access to forensic logs is available through `GET /api/audit/logs` and the `Forensic logs` screen.
- Preserve UTC timestamps during exports, use the app-provided local timestamp for operator review, and correlate events using `request_id` and `correlation_id`.
- Audit snapshots must not expose uploaded note text, original filenames, storage paths, vendor connection material, local access material, encryption material, or PHI-like clinical content.

## Patient note set handling

- Patient note uploads are keyed by `patient_id` and stored under the encrypted local upload directory.
- Patient ID is the only patient identifier used for local upload/import/display/export/log workflows. Patient names, addresses, source filenames, attachment URLs, author/custodian labels, and contact-style direct identifiers are not used as local display labels or matching keys.
- Initial uploads use `POST /api/patient-note-sets` with `upload_mode=initial`; later changes use `upload_mode=update`, which creates a new immutable version instead of replacing the prior set.
- Current and historical binders can be listed with `GET /api/patient-note-sets` and inspected with `GET /api/patient-note-sets/{id}`.
- Stored source files can be retrieved with `GET /api/patient-note-sets/{note_set_id}/documents/{document_id}/download` after authentication and authorization checks.
- Uploaded binders can be deleted with `DELETE /api/patient-note-sets/{id}` by an authorized user. Deletion removes the selected note set, linked generated review charts, upload-derived timeliness records, and encrypted stored files. If the deleted binder was the current active version and an older version remains, the latest remaining version is reactivated and resynced into the timeliness tracker.
- Admins can clear all local patient/chart/treatment-plan/manual-upload/review data with `DELETE /api/patient-data` by supplying the exact confirmation phrase `CLEAR ALL PATIENT DATA`. This preserves app settings, API credentials, user accounts, audit logs, rules, and docs.
- Every stored file has a SHA-256 digest in the database; use that hash when validating backup integrity or investigating file tampering.
- Forensic audit logs are retained after binder deletion.

## Treatment Plan Timeliness operations

- Admins and office managers normally land on the Treatment Plans work queue when no explicit view is requested.
- The primary navigation should show the daily work areas `Status Dashboard`, `Treatment plans`, `Review queue`, and `Manual upload`; less-frequent support/admin pages should appear as smaller shortcuts.
- Use `docs\patient-treatment-plan-handling.md` as the implementation map for treatment-plan storage, sync, aggregate, deterministic evaluation, selected-client checklist results, and UI code locations.
- The queue uses deterministic rules and current Beta 1.4.6-beta.1 text-labeled statuses for overdue, urgent, due soon, returned, needs review, missing data, conflicting evidence, unable-to-evaluate, approved, and compliant records.
- The selected-client detail view compares source-document `Next Review Due`, staff-signature cadence due date, and LOC-effective cadence due date.
- If source-document next-due evidence disagrees with the date-clock due date and there is no validated LOC-change anchor, the expected result is a review/error state such as `Needs Review`, not silent compliance.
- The selected-client detail also shows current treatment-plan content counts/facts, data-quality warnings, source confidence, current-plan selection, LOC history, treatment-plan evidence, rule results, 42-step checklist rows, manager notes, and manual overrides.
- Alleva/API lookup status and result details should remain inside bounded scroll areas so lookup progress does not expand the page and hide lower controls.
- Managers can save status/comments on each selected-client 42-step checklist criterion and export a counselor action CSV for that client.
- Review Queue remains the generated/manual uploaded-binder chart-review workbench. Treatment Plans remains the active due-date/timeliness work queue.
- Manual overrides are restricted to admins and office managers and must be audited with a reason.
- Counselors do not have Treatment Plans queue access because that table does not have explicit counselor ownership; they continue to use role-scoped review, upload, and account workflows.
- The LOC-change treatment-plan update window is still unvalidated and must stay configurable and visibly marked as unresolved.

## API readiness checks

- The admin API harness is available at `/api-configuration` in the Windows desktop runtime.
- When opened from App settings, the harness uses the current admin session; it should not prompt for a second admin login inside the harness.
- App settings holds the single active Alleva/API connection. The harness loads and tests that active connection; saved endpoint profiles are optional presets that must be activated before they affect readiness checks or sync.
- Pasting the R3/Alleva client ID and client secret is expected for OAuth client-credentials setup. Stored secrets are encrypted locally and are never returned to the browser after save.
- The harness supports API-key auth, no-auth probes, and OAuth client credentials using body credentials, Basic auth, URL-encoded Basic auth, or try-both/try-all fallback modes.
- Operation-test responses are capped before returning to the UI. Large responses are marked as truncated and summarized instead of rendering the full payload.
- Periodic API readiness checks can be enabled in App settings after saving REST API base URL, OpenAPI URL, token URL, client ID, encrypted client secret, token auth style, and interval.
- Alleva has confirmed it does not currently support FHIR. Active integration is Alleva REST/OpenAPI/HL7-readiness only.
- Stored API endpoint profiles are admin-only and can be activated for the current readiness/API test configuration without returning stored secrets to the browser.
- Periodic checks authenticate and pull/summarize API definitions only. They do not import live Alleva patient data until the live-import compliance gate is cleared.

## Alleva REST treatment-plan sync

- `Test-AllevaApi.ps1` uses Alleva REST API base URL, token URL, and Swagger/OpenAPI definitions.
- App startup sync uses the same REST concept. It is disabled by default.
- Manual retrieval is available from the Status Dashboard EMR/API card and from App Settings, but it uses the same approval and mapping gates as startup sync.
- Admins can run the API-harness `patient_treatment_plan_aggregates` dry-run to compare `/clients`, `/treatment-plans`, and `/treatment-reviews` coverage without enabling live sync.
- To arm startup sync, App settings must have Alleva REST API base URL, token URL, client ID, encrypted client secret, explicit R3/Alleva live-sync approval, and validated endpoint mapping.
- Endpoint mapping must confirm active-client filtering, treatment-plan records, treatment-review records, staff/creator signature dates, client signature dates, current LOC, admission date, next review due, pagination, and status fields.
- Patient-name import/display is off by default. When it is off, Alleva-sourced Treatment Plan clients keep generated `no-name-found_YYYY-MM-DD_HHMMSS` display labels; saving App settings with the control off redacts existing Alleva-sourced names again.
- Name-fallback matching is a separate validation-only setting. Keep it off unless R3 is actively validating endpoint ID mapping.
- When sync runs, Alleva is only the source system. The app normalizes the REST payloads into local timeliness records and runs R3's deterministic compliance logic.
- Current-plan detail fetch is optional and capped. When enabled it stores counts and PHI-minimized content facts, not raw narrative text.
- If required approval or mapping is missing, the sync records a blocked status and imports no live patient treatment-plan data.

## Treatment-plan date clock

- The timeliness evaluator uses the laptop/facility-local current date on startup and during runtime.
- The recurring update clock starts from the latest valid treatment-plan review/update date, or from admission date when no later valid review/update exists.
- PHP levels use 30 calendar days; other configured treatment levels use 60 calendar days.
- Due today and one day before due are `Urgent`; two through seven days before due are `Due Soon`; eight or more days before due are `Compliant`; only dates before the evaluation date are `Overdue`.
- LOC changes use a separate manager-editable 7-calendar-day preset. The setting remains unvalidated until R3/Marleigh confirms the final rule.
- Every timeliness analysis result is audited with patient ID, status, due date, rule used, current date, and active workflow key/version/checklist context.
- Exports include both the legacy checklist/domain rows and active workflow-step statuses.

## Roles and workflow controls

- Admins can use every screen and action, including all user roles, App settings, API/EMR, LLM, workflow profiles, logs, uploads, reviews, overrides, and exports.
- Office managers can manage counselor accounts and Workflow profiles, approve/return reviews, and record treatment-plan overrides. They cannot open App settings, API/EMR setup, LLM setup, forensic logs, or manage admin/manager accounts.
- Counselors can upload/update their own work, review returned work, view permitted details, export permitted work lists, and manage only their own account.
- Workflow profile create/version/edit-draft/publish/archive/delete attempts are audited. Published/archived workflow history must remain available for interpreting historical metrics.

## Windows desktop runtime

- The ordinary Windows path runs one local FastAPI desktop service at `http://localhost:8000`.
- The default database is SQLite under `%LOCALAPPDATA%\IZ Clinical Notes Analyzer`.
- Uploads, logs, API reports, and `.env` also live under `%LOCALAPPDATA%\IZ Clinical Notes Analyzer`.
- Use `scripts\Start-IZ-Clinical-Notes-Analyzer.cmd` for double-click launch.
- Ordinary launch prompts before installing missing dependencies or rebuilding frontend assets.
- Use `scripts\preflight-windows.ps1 -AssumeYes` only for unattended support validation.
- Use `scripts\collect-diagnostics.ps1` or the `IZ Clinical Notes Analyzer Diagnostics` shortcut to collect a redacted support bundle. The bundle excludes uploads, local databases, generated reports, and raw `.env` values.
- Use `scripts\Backup-IZ-Clinical-Notes-Analyzer.cmd` or the `Backup IZ Clinical Notes Analyzer` shortcut to create a full local-data backup zip.
- Use normal uninstall to preserve local data for reinstall/upgrade; use complete uninstall only after backup or an explicit R3 data-destruction decision.
- Do not move runtime data into the OneDrive-backed source repository.

## Recovery

- If the Windows app will not start, inspect `%LOCALAPPDATA%\IZ Clinical Notes Analyzer\logs\preflight-windows-latest.json` and the startup logs in the same AppData tree.
- If no local admin can sign in, follow `docs\admin-access-reset.md`.
- If the browser shows an old UI, rebuild `frontend\dist` or use a freshly built release folder.
- If API readiness fails, use `docs\api-configuration-and-connectivity.md` and keep live patient import disabled until approved vendor details and endpoint mapping are available.

## Backup and restore

For ordinary Windows desktop installs:

1. Stop the app.
2. Run `Backup IZ Clinical Notes Analyzer` from the Start Menu, or run `scripts\backup-local-data.ps1`.
3. Confirm the backup zip is written under `%USERPROFILE%\Documents\IZ Clinical Notes Analyzer Backups`.
4. Keep the backup encrypted and access-controlled because it can contain local SQLite data, encrypted uploads, audit logs, configuration, saved API configuration, and encryption material.
5. Restore by stopping the local app, replacing the AppData directory from the approved backup, and restarting the app.

The `.env` file, SQLite database, and encrypted uploads must stay together. If the `.env` file is lost, encrypted uploads and saved API configuration may not be recoverable.

## Legacy Docker/PostgreSQL artifacts

Docker/PostgreSQL is not the current supported R3 Windows desktop path. The root full-stack `docker-compose.yml` is not active in this branch. The old Docker/nginx archive folder and database-expose compose overlay were removed on 2026-06-17 after cleanup evidence; later legacy startup/helper scripts were moved under `depricated/` and must not be used as launch instructions.

Do not present Docker, PostgreSQL, nginx, Git, Node.js, or command-line work as ordinary Windows desktop-user requirements. Do not restore the old Docker stack to active paths unless R3 explicitly reintroduces Docker/server deployment and updates README, Windows docs, CI, tests, and release instructions together.
