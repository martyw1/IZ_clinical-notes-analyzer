import json

from fastapi.testclient import TestClient
from sqlalchemy import select

from app.models.models import AuditLog
from app.services.access_intel import AccessIntelResult

BOOTSTRAP_ADMIN_PASSWORD = 'r3!@analyzer#123'


def _auth_headers(client: TestClient) -> dict[str, str]:
    login = client.post('/api/auth/login', json={'username': 'admin', 'password': BOOTSTRAP_ADMIN_PASSWORD})
    assert login.status_code == 200
    return {'Authorization': f"Bearer {login.json()['access_token']}"}


def test_chart_changes_emit_forensic_audit_records(app_with_sqlite):
    app, session_local = app_with_sqlite

    with TestClient(app) as client:
        headers = _auth_headers(client)
        created = client.post(
            '/api/charts',
            headers=headers,
            json={
                'patient_id': 'PAT-001',
                'client_name': 'Patient-001',
                'level_of_care': 'Residential',
                'admission_date': '04/01/2025',
                'discharge_date': '09/10/2025',
                'primary_clinician': 'Clinician A',
                'auditor_name': 'admin',
                'other_details': '',
                'notes': 'Initial draft.',
            },
        )
        assert created.status_code == 200
        chart_id = created.json()['id']

        checklist_items = created.json()['checklist_items']
        checklist_items[0]['status'] = 'yes'
        checklist_items[0]['evidence_location'] = 'Client Overview'

        updated = client.put(
            f'/api/charts/{chart_id}',
            headers=headers,
            json={
                'patient_id': 'PAT-001',
                'client_name': 'Patient-001',
                'level_of_care': 'Residential',
                'admission_date': '04/01/2025',
                'discharge_date': '09/10/2025',
                'primary_clinician': 'Clinician B',
                'auditor_name': 'admin',
                'other_details': 'Follow-up review.',
                'notes': 'Updated after verification.',
                'checklist_items': checklist_items,
            },
        )
        assert updated.status_code == 200

    db = session_local()
    try:
        logs = list(db.execute(select(AuditLog).order_by(AuditLog.id.asc())).scalars().all())
        assert logs

        http_log = next(log for log in logs if log.action == 'http.request.completed' and log.request_path == '/api/charts')
        assert http_log.source_ip is not None
        assert http_log.request_id
        assert http_log.correlation_id
        assert http_log.http_status_code == 200
        assert http_log.cef_payload.startswith('CEF:0|')

        insert_log = next(
            log for log in logs if log.action == 'data.insert.commit' and log.target_entity_type == 'chart' and log.target_entity_id == str(chart_id)
        )
        assert insert_log.before_state is None
        assert insert_log.after_state is not None
        assert '"patient_id":"PAT-001"' in insert_log.after_state
        assert '"client_name":"PAT-001"' in insert_log.after_state
        assert 'Patient-001' not in insert_log.after_state

        update_log = next(
            log for log in logs if log.action == 'data.update.commit' and log.target_entity_type == 'chart' and log.target_entity_id == str(chart_id)
        )
        diff_state = json.loads(update_log.diff_state or '{}')
        assert 'primary_clinician' in diff_state
        assert diff_state['primary_clinician']['before'] == 'Clinician A'
        assert diff_state['primary_clinician']['after'] == 'Clinician B'
        assert update_log.patient_id == 'PAT-001'
        assert update_log.route_template == '/api/charts/{chart_id}'
        assert update_log.actor_username == 'admin'
    finally:
        db.close()


def test_audit_log_endpoint_returns_enriched_records(app_with_sqlite):
    app, session_local = app_with_sqlite

    with TestClient(app) as client:
        headers = _auth_headers(client)
        response = client.get('/api/audit/logs', headers=headers)
        assert response.status_code == 200
        payload = response.json()
        assert payload
        first_record = payload[0]
        assert 'cef_payload' in first_record
        assert 'event_category' in first_record

    db = session_local()
    try:
        read_log = db.execute(select(AuditLog).where(AuditLog.action == 'audit.logs.read')).scalar_one_or_none()
        assert read_log is not None
        assert read_log.event_category == 'forensic_access'
    finally:
        db.close()


def test_ui_button_events_are_logged_without_unapproved_context(app_with_sqlite):
    app, session_local = app_with_sqlite

    with TestClient(app) as client:
        headers = _auth_headers(client)
        response = client.post(
            '/api/ui-events',
            headers=headers,
            json={
                'screen': 'reviews',
                'action_name': 'Dig deeper',
                'result': 'clicked',
                'context': {
                    'button_text': 'Dig deeper',
                    'view': 'reviews',
                    'patient_name': 'Do Not Persist',
                    'api_key': 'do-not-persist',
                },
            },
        )
        assert response.status_code == 204

    db = session_local()
    try:
        ui_log = db.execute(select(AuditLog).where(AuditLog.action == 'ui.button.click')).scalar_one()
        assert ui_log.event_category == 'ui_interaction'
        assert ui_log.target_entity == 'Dig deeper'
        assert 'button_text' in ui_log.details
        assert 'Do Not Persist' not in ui_log.details
        assert 'do-not-persist' not in ui_log.details
    finally:
        db.close()


def test_login_access_attempts_capture_ip_intelligence(app_with_sqlite, monkeypatch):
    app, session_local = app_with_sqlite

    monkeypatch.setattr(
        'app.api.auth_user_routes.lookup_access_intel',
        lambda *_args, **_kwargs: AccessIntelResult(
            source_ip='8.8.8.8',
            ip_scope='public',
            geolocation={'country': 'United States', 'region': 'Virginia', 'city': 'Ashburn'},
            reputation={'abuse_confidence_score': 12},
            lookup_status='complete',
            danger_score=12,
            dangerous=False,
            danger_summary='This IP is not dangerous based on the current geolocation and reputation evidence.',
        ),
    )

    with TestClient(app) as client:
        login = client.post('/api/auth/login', json={'username': 'admin', 'password': BOOTSTRAP_ADMIN_PASSWORD}, headers={'x-forwarded-for': '8.8.8.8'})
        assert login.status_code == 200

    db = session_local()
    try:
        access_log = db.execute(select(AuditLog).where(AuditLog.action == 'auth.login.success')).scalar_one_or_none()
        assert access_log is not None
        assert access_log.event_category == 'access_attempt'
        details = json.loads(access_log.details)
        assert details['source_ip'] == '8.8.8.8'
        assert details['geolocation']['country'] == 'United States'
        assert details['danger_summary'].startswith('This IP is not dangerous')
    finally:
        db.close()
