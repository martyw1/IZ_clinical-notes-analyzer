﻿[CmdletBinding()]
param(
    [string]$InstalledAppRoot = '',
    [switch]$NoPause,
    [int]$DelaySeconds = 0
)

$ErrorActionPreference = 'Stop'
if ($DelaySeconds -gt 0) {
    Start-Sleep -Seconds $DelaySeconds
}
$InstallRoot = if ($InstalledAppRoot) { $InstalledAppRoot } else { Join-Path $env:LOCALAPPDATA 'Programs\IZ Clinical Notes Analyzer' }
$ExpectedInstallRoot = Join-Path $env:LOCALAPPDATA 'Programs\IZ Clinical Notes Analyzer'
$StartMenuDir = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\IZ Clinical Notes Analyzer'
$DesktopDir = [Environment]::GetFolderPath('Desktop')
$DesktopShortcuts = @(
    'IZ Clinical Notes Analyzer.lnk',
    'IZ Clinical Notes Analyzer Diagnostics.lnk',
    'IZ Clinical Notes Analyzer Backup.lnk'
) | ForEach-Object { Join-Path $DesktopDir $_ }

function Get-NormalizedPath {
    param([string]$Path)
    $trimChars = [char[]]@([System.IO.Path]::DirectorySeparatorChar, [System.IO.Path]::AltDirectorySeparatorChar)
    return [System.IO.Path]::GetFullPath($Path).TrimEnd($trimChars)
}

function Assert-ExpectedPath {
    param(
        [string]$Path,
        [string]$Expected,
        [string]$Label
    )
    $normalizedPath = Get-NormalizedPath -Path $Path
    $normalizedExpected = Get-NormalizedPath -Path $Expected
    if (-not $normalizedPath.Equals($normalizedExpected, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "$Label resolved to $normalizedPath, expected $normalizedExpected"
    }
}

Assert-ExpectedPath -Path $InstallRoot -Expected $ExpectedInstallRoot -Label 'Install folder'
Assert-ExpectedPath -Path $StartMenuDir -Expected (Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\IZ Clinical Notes Analyzer') -Label 'Start Menu folder'

$normalizedInstallRoot = Get-NormalizedPath -Path $InstallRoot
if ($PSCommandPath) {
    $normalizedScriptPath = Get-NormalizedPath -Path $PSCommandPath
    $separator = [System.IO.Path]::DirectorySeparatorChar
    if ($normalizedScriptPath.StartsWith("$normalizedInstallRoot$separator", [System.StringComparison]::OrdinalIgnoreCase)) {
        $helperPath = Join-Path ([System.IO.Path]::GetTempPath()) "iz-cna-uninstall-$([System.Guid]::NewGuid().ToString('N')).ps1"
        Copy-Item -LiteralPath $PSCommandPath -Destination $helperPath -Force
        $argList = "-NoProfile -ExecutionPolicy Bypass -File `"$helperPath`" -InstalledAppRoot `"$InstallRoot`" -NoPause -DelaySeconds 2"
        Start-Process -FilePath 'powershell.exe' -ArgumentList $argList -WindowStyle Hidden
        Write-Host 'Uninstall cleanup started. The app folder will be removed in a few seconds.'
        Write-Host "Local data under %LOCALAPPDATA%\IZ Clinical Notes Analyzer will be preserved."
        exit 0
    }
}

$stopScript = Join-Path $InstallRoot 'scripts\stop-windows-local.ps1'
if (Test-Path -LiteralPath $stopScript) {
    Write-Host 'Stopping any running local app process...'
    & $stopScript -NoRestartPrompt -NoPause
}
Set-Location ([System.IO.Path]::GetTempPath())

foreach ($shortcut in $DesktopShortcuts) {
    if (Test-Path -LiteralPath $shortcut) {
        Remove-Item -LiteralPath $shortcut -Force
    }
}

if (Test-Path $StartMenuDir) {
    Remove-Item -LiteralPath $StartMenuDir -Recurse -Force
}
if (Test-Path $InstallRoot) {
    Remove-Item -LiteralPath $InstallRoot -Recurse -Force
}
Write-Host "Removed IZ Clinical Notes Analyzer application files and shortcuts."
Write-Host "Local data under %LOCALAPPDATA%\IZ Clinical Notes Analyzer was preserved."
