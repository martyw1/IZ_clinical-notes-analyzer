@echo off
setlocal
set "PACKAGE_DIR=%~dp0"
set "NO_PAUSE="
for %%A in (%*) do (
    if /I "%%~A"=="-NoPause" set "NO_PAUSE=1"
    if /I "%%~A"=="/NoPause" set "NO_PAUSE=1"
)
cd /d "%PACKAGE_DIR%"
title IZ Clinical Notes Analyzer
echo Starting IZ Clinical Notes Analyzer...
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PACKAGE_DIR%app\scripts\start-windows-local.ps1" -AssumeYes %*
set "EXIT_CODE=%ERRORLEVEL%"
if not "%EXIT_CODE%"=="0" (
    echo.
    echo [fail] The app did not start.
    echo Review the startup log under %%LOCALAPPDATA%%\IZ Clinical Notes Analyzer\logs.
    echo Send a screenshot of this window to R3 support if the message is unclear.
    echo.
    if not "%NO_PAUSE%"=="1" pause
)
exit /b %EXIT_CODE%
