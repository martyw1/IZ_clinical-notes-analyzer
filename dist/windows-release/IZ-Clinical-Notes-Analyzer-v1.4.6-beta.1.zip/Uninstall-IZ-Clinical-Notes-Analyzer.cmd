@echo off
setlocal
set "PACKAGE_DIR=%~dp0"
set "NO_PAUSE="
for %%A in (%*) do (
    if /I "%%~A"=="-NoPause" set "NO_PAUSE=1"
    if /I "%%~A"=="/NoPause" set "NO_PAUSE=1"
)
title Uninstall IZ Clinical Notes Analyzer
echo Uninstall IZ Clinical Notes Analyzer app files
echo Local data under %%LOCALAPPDATA%%\IZ Clinical Notes Analyzer will be preserved.
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PACKAGE_DIR%installer\uninstall-windows-release.ps1" %*
set "EXIT_CODE=%ERRORLEVEL%"
echo.
if "%EXIT_CODE%"=="0" (
    echo [ok] Uninstall completed. Local data was preserved.
) else (
    echo [fail] Uninstall did not complete.
)
echo.
if not "%NO_PAUSE%"=="1" pause
exit /b %EXIT_CODE%
