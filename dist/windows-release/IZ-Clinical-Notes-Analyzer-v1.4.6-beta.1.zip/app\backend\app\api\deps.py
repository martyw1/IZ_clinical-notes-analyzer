from fastapi import Depends, HTTPException, Request, status
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError, jwt
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.security import ALGORITHM
from app.db.session import get_db
from app.models.models import Role, User
from app.services.audit import log_event, refresh_session_audit_context, set_actor_context

oauth2_scheme = OAuth2PasswordBearer(tokenUrl='/api/auth/login')
PASSWORD_RESET_ALLOWED_PATHS = {'/api/auth/reset-password', '/api/users/me/change-password', '/api/users/me', '/api/health', '/health'}


def get_current_user(request: Request, db: Session = Depends(get_db), token: str = Depends(oauth2_scheme)) -> User:
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail='Could not validate credentials',
        headers={'WWW-Authenticate': 'Bearer'},
    )
    try:
        payload = jwt.decode(token, settings.secret_key, algorithms=[ALGORITHM])
        username: str | None = payload.get('sub')
    except JWTError as exc:
        raise credentials_exception from exc
    if not username:
        raise credentials_exception
    user = db.execute(select(User).where(User.username == username)).scalar_one_or_none()
    if not user:
        raise credentials_exception
    if not user.is_active:
        log_event(
            db,
            request,
            'auth.token.blocked',
            actor=user,
            event_category='authentication',
            target_entity='user',
            target_entity_type='user',
            target_entity_id=str(user.id),
            details={'username': user.username, 'reason': 'inactive'},
            outcome_status='failure',
            severity='warning',
            http_status_code=403,
            message=f'Inactive account {user.username} attempted API access.',
        )
        raise HTTPException(status_code=403, detail='Account inactive')
    if user.is_locked:
        log_event(
            db,
            request,
            'auth.token.blocked',
            actor=user,
            event_category='authentication',
            target_entity='user',
            target_entity_type='user',
            target_entity_id=str(user.id),
            details={'username': user.username, 'reason': 'locked'},
            outcome_status='failure',
            severity='warning',
            http_status_code=403,
            message=f'Locked account {user.username} attempted API access.',
        )
        raise HTTPException(status_code=403, detail='Account locked')
    if user.must_reset_password and request.url.path not in PASSWORD_RESET_ALLOWED_PATHS:
        raise HTTPException(status_code=403, detail='Password reset required before accessing clinical data')
    set_actor_context(user, request)
    refresh_session_audit_context(db)
    return user


def require_roles(*roles: Role):
    def role_checker(user: User = Depends(get_current_user)) -> User:
        if user.role not in roles:
            raise HTTPException(status_code=403, detail='Insufficient permissions')
        return user

    return role_checker
