@echo off
setlocal
set "PACKAGE_DIR=%~dp0"
set "NO_PAUSE="
for %%A in (%*) do (
    if /I "%%~A"=="-NoPause" set "NO_PAUSE=1"
    if /I "%%~A"=="/NoPause" set "NO_PAUSE=1"
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PACKAGE_DIR%app\scripts\stop-windows-local.ps1" %*
set "EXIT_CODE=%ERRORLEVEL%"
if not "%EXIT_CODE%"=="0" if not "%NO_PAUSE%"=="1" pause
exit /b %EXIT_CODE%
